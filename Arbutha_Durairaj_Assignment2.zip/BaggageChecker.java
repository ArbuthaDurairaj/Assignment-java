package baggageairline;

/*ClassName:BaggageChecker
Student:Arbutha Durairaj
Lab Professor:Prof.Dave Houtman
Due Date: July 26,2024
Description:The class program for BaggageChecker*/

public class BaggageChecker {
	public static final float MAX_REGULAR_WEIGHT = 22.0F;
	public static final float SURCHARGE_PER_KG = 3.00F;
	public static final int MAX_CARRYON_DIMENSION = 36;
	public static final int MAX_SUM_DIMENSIONS = 192;

/*This method is to check for the baggage overweight. 
  which is the weight more than the MAX_REGULAR_WEIGHT*/

	public static boolean allowedWeightIsMoreThanMax(Baggage baggage) {
		boolean isallowableweight;
		if (baggage.getBagWeight() > MAX_REGULAR_WEIGHT) {
			isallowableweight = true;
		} else {
			isallowableweight = false;
		}
		return isallowableweight;
	}

//This method is used to calculate the extra/additional charge for the baggage if it is overweight

	public static float calculateWeightSurcharge(Baggage baggage) {
		float weightsurcharge;
		weightsurcharge = (float) ((baggage.getBagWeight() - MAX_REGULAR_WEIGHT) * SURCHARGE_PER_KG);
		return weightsurcharge;
	}

//This method is to detect the baggage can be used as carry on

	public static boolean canBeUsedAsACarryOn(Baggage baggage) {
		boolean bag = (baggage.getBagLength() < MAX_CARRYON_DIMENSION)
				&& (baggage.getBagWidth() < MAX_CARRYON_DIMENSION) && (baggage.getBagHeight() < MAX_CARRYON_DIMENSION)
						? true
						: false;
		return bag;
	}

/*This method is to calculate the sum of dimensions and 
also check for sum of dimensions exceeds MAX_SUM_DIMENSIONS*/

	public static boolean sumDimensionsExceedsMax(Baggage baggage) {
		double sum = baggage.getBagLength() + baggage.getBagWidth() + baggage.getBagHeight();
		boolean issum;
		if (sum > MAX_SUM_DIMENSIONS) {
			issum = true;
		} else {
			issum = false;
		}
		return issum;
	}
}
