package baggageairline;

/*ClassName:Baggage
Student:Arbutha Durairaj
Lab Professor:Prof.Dave Houtman
Due Date: July 26,2024
Description:The class program for Baggage*/

public class Baggage {

	private int baglength;
	private int bagwidth;
	private int bagheight;
	private double bagweight;

	public static final int DEFAULT_LENGTH = 65;
	public static final int DEFAULT_WIDTH = 25;
	public static final int DEFAULT_HEIGHT = 50;
	public static final double DEFAULT_WEIGHT = 10.0F;

	public Baggage() {
		this(DEFAULT_LENGTH, DEFAULT_WIDTH, DEFAULT_HEIGHT, DEFAULT_WEIGHT);
	}

	public Baggage(int baglength, int bagwidth, int bagheight, double bagweight) {
		this.baglength = baglength;
		this.bagwidth = bagwidth;
		this.bagheight = bagheight;
		this.bagweight = bagweight;
	}

	public int getBagLength() {
		return baglength;
	}

	public void setBagLength(int baglength) {
		this.baglength = baglength;
	}

	public int getBagWidth() {
		return bagwidth;
	}

	public void setBagWidth(int bagwidth) {
		this.bagwidth = bagwidth;
	}

	public int getBagHeight() {
		return bagheight;
	}

	public void setBagHeight(int bagheight) {
		this.bagheight = bagheight;
	}

	public double getBagWeight() {
		return bagweight;
	}

	public void setBagWeight(double bagweight) {
		this.bagweight = bagweight;
	}

/*The method toString() returns a string output
 * which summarizing the properties of each instantiated piece of baggage 
 * and describes the baggage can be used as a carry on.
 * It also displays the overweight status and 
 * display extra charge for overweight if applicable */

	public String toString() {

		String output = String.format("The bag has length %d Cm ,width %d Cm ,height %d cm ,and weight %.2f Kg ",
				baglength, bagwidth, bagheight, bagweight);

		if (BaggageChecker.canBeUsedAsACarryOn(this)) {
			output += "\nThis bag can be used as a carry on.";
		}
		if (BaggageChecker.allowedWeightIsMoreThanMax(this)) {
			output += String.format(
					"\nThis bag is overweight; it exceeds the allowed weight of %.2f, kg."
							+ " A surcharge of $ %.2f applies.",
					BaggageChecker.MAX_REGULAR_WEIGHT, BaggageChecker.calculateWeightSurcharge(this));
		}

		return output;
	}

}
