package baggageairline;

/*ClassName:Baggagelauncher
Student:Arbutha Durairaj
Lab Professor:Prof.Dave Houtman
Due Date: July 26,2024
Description:The main program for BaggageLauncher*/


public class BaggageLauncher {

/* The main() method prompts the user to enter the dimensions of the baggage and 
 * also prompts the user to continue until they enter “No”, and 
 * then output the total number of valid bags entered and 
 * total weight of Baggage and also the program terminated*/

	public static void main(String[] args) {
		System.out.println("Welcome to the Baggage Handler Software Program");
		int validbagggecount = 0;
		float totalbaggageweight = 0.00F;
		boolean iscontinue = false;
		int baglength, bagwidth, bagheight;
		double bagweight;
		  do {
			baglength = InputData.validateInt("Enter the length of the Baggage(in cm):");
			bagwidth = InputData.validateInt("Enter the width (in cm): ");
			bagheight = InputData.validateInt("Enter the height (in cm):");
			bagweight = InputData.validateDouble("Enter the weight (in Kg):");

			Baggage baggage = new Baggage(baglength, bagwidth, bagheight, bagweight);

			if (!BaggageChecker.sumDimensionsExceedsMax(baggage)) {
				totalbaggageweight = (float) (totalbaggageweight + baggage.getBagWeight());
				InputData.validateString(baggage.toString());
				validbagggecount++;

			} else {
				InputData.validateString("This is oversized; it is not acceptable.");

			}
			String shouldcontinue = InputData
					.validateString(" Do you wish to continue? Enter 'No' to quit, anything else to continue:");
			if (shouldcontinue.equalsIgnoreCase("No")) {
				iscontinue = false;
			} else {
				iscontinue = true;
			}

		} while (iscontinue);

		InputData.validateString("The total number of valid bags entered was: " + validbagggecount);
		String total = String.format("The total weight entered was: %.2f", totalbaggageweight);
		InputData.validateString(total);
		InputData.validateString("The program has terminated.");
		InputData.validateString("Program by Arbutha Durairaj");

	}
}
