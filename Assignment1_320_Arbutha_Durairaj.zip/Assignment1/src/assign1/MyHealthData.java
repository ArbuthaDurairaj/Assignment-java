package assign1;
import java.time.LocalDate;
/*• Author: [Arbutha Durairaj,041156799] 
• Course: CST8284-Object Oriented Programming
• Assignment: Assignment1
• Date:October11,2024
• Professor:Gustavo Adami
• Purpose:Creating and maintaining Electronic health records of patients in hospital
• Class list: */
/**
 * This class is designed to calculate Target Heart Rate Range of patients and 
 * displaying patient's information by inheriting
 *  patient's health records from MyHealthDatabase class
@author Arbutha_Durairaj
 * @version 1.2
 * @see MyHealthData
 * @since 17.0.11
*/
public class MyHealthData extends MyHealthDatabase{
	private String firstName;
	private String lastName;
	private String gender;
	private int birthYear;
	private int currentYear;
	private double height;
	private double weight; 
	private static LocalDate CurrentDate=LocalDate.now();
	
	/**
	 * Get the patient's information.
	 * 
	 * @param firstName  the firstName of the patient
	 * @param lastName the lastName of the patient
	 * @param gender the gender of the patient
	 * @param height the height of the patient
	 * @param weight the weight of the patient
	 * @param birthYear the birthYear of the patient
	 * @param currentYear the current year*/
	
	public MyHealthData(String firstName, String lastName, String gender, double height,double weight, int birthYear,int currentYear) {
		
		    this.firstName = firstName;
	        this.lastName = lastName;
	        this.gender = gender;
	        this.height = height;
	        this.weight = weight;
	        this.birthYear = birthYear;
	        this.currentYear=CurrentDate.getYear();
	       
		
	}
	/**Get the firstName of the patient
	 * @return The firstName of the patient
	 * @author Arbutha_Durairaj
	*/
	public String getFirstName() {
		return firstName;
	}
	/*** set the FirstName 
	 * @param firstName the firstName of the patient*/
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**Get the LastName of the patient
	 * @return The LastName of the patient
	 * @author Arbutha_Durairaj
	*/

	public String getLastName() {
		return lastName;
	}
	/*** set the lastName 
	 * @param lastName the lastName of the patient*/
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**Get the gender information of the patient
	 * @return The gender of the patient
	 * @author Arbutha_Durairaj
	*/
	public String getGender() {
		return gender;
	}
/*** set the gender 
 * @param gender patient's gender*/
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**Get the birthYear of the patient
	 * @return The birthYear of the patient
	 * @author Arbutha_Durairaj
	*/
	public int getBirthYear() {
		return birthYear;
	}
/*** set the BirthYear 
 * @param birthYear patient's birth date*/
	public void setBirthYear(int birthYear) {
		this.birthYear = birthYear;
	}
	/**Get the currentYear of the patient
	 * @return The currentYear of the patient
	 * @author Arbutha_Durairaj
	*/
	public int getCurrentYear() {
		return currentYear;
	}
	/**Get the height information  of the patient
	 * @return The height of the patient
	 * @author Arbutha_Durairaj
	*/

	public double getHeight() {
		return height;
	}
	/*** set the current height 
	 * @param height patient's height*/
	public void setHeight(double height) {
		this.height = height;
	}
	/**Get the weight information  of the patient
	 * @return The weight of the patient
	 * @author Arbutha_Durairaj
	*/
	
	public double getWeight() {
		return weight;
	}
	/*** set the current weight 
	 * @param weight patient's weight*/
	public void setWeight(double weight) {
		this.weight = weight;
	}
	/**calculate the age of the patient from patient's birthYear
	 * @return The age of the patient
	 * @author Arbutha_Durairaj
	*/
	
	public int getAge() {
		int age=currentYear-birthYear;
		return age;
	}
	/**calculate the maximum heart rate range of patient from patient's age
	 * @return The maximum_heart_rate of the patient
	 * @author Arbutha_Durairaj
	*/
	public int calculateMaximumHeartRate() {
		int maximum_heart_rate= 220-getAge();	
		return maximum_heart_rate;
	}
	/**calculate the Target Heart Rate Range of patient 
	 * @return The  minTargetHeartRate, maxTargetHeartRate of the patient
	 * @author Arbutha_Durairaj
	*/
	// Method to calculate Target Heart Rate Range
    public double[] calculateTargetHeartRateRange() {
        double maxHeartRate = calculateMaximumHeartRate();
        double minTargetHeartRate = 0.50 * maxHeartRate; // 50% of Maximum Heart Rate
        double maxTargetHeartRate = 0.85 * maxHeartRate; // 85% of Maximum Heart Rate
        return new double[] { minTargetHeartRate, maxTargetHeartRate };
    }
 /**Method to display patient's health data*/
    public void displayMyHealthData() {
        // Using System.out.printf to show all health data
    	System.out.println("---patient's information----");
        System.out.printf("Patient's First Name: %s%n", firstName);
        System.out.printf("Patient's Last Name: %s%n", lastName);
        System.out.printf("Patient's Gender: %s%n", gender);
        System.out.printf("Patient's Year of Birth: %d%n", birthYear);
        System.out.printf("Patient's Height (inches): %.2f%n", height);
        System.out.printf("Patient's Weight (pounds): %.2f%n", weight);
        System.out.printf("Patient's Age (years): %d%n", getAge());
        System.out.printf("Patient's BMI: %.2f%n", calculateBMI(weight, height));
        System.out.printf("Patient's Maximum Heart Rate: %d%n", calculateMaximumHeartRate());

       double[] targetHeartRate = calculateTargetHeartRateRange();
        System.out.printf("Patient's Minimum Target Heart Rate: %.2f%n", targetHeartRate[0]);
        System.out.printf("Patient's Maximum Target Heart Rate: %.2f%n", targetHeartRate[1]);

        // Displaying BMI values
        System.out.println("BMI VALUES");
        System.out.println("Underweight: less than 18.5");
        System.out.println("Normal:      between 18.5 and 24.9");
        System.out.println("Overweight:  between 25 and 29.9");
        System.out.println("Obese:       30 or greater");
       
    }
    

} // end class MyHealthData


