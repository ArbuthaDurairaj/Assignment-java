package assign1;
/*• Author: [Arbutha Durairaj,041156799] 
• Course: CST8284-Object Oriented Programming
• Assignment: Assignment1
• Date:October11,2024
• Professor:Gustavo Adami
• Purpose:The purpose of this test is to ensure the BMI calculation */

import org.junit.Assert;
import org.junit.Test;

/** Test case class for testing various methods*/
public class MyHealthDatatest2 {
	private static final double EPSILON = 1E-12;

	@Test
	/*** Method for successful test of BMI calculation*/
	//Test case for calculateBMI method
	public void testcalculateBMI() {
		MyHealthDatabase healthdatabase=new MyHealthDatabase();
		double actualBMI=healthdatabase.calculateBMI(160, 70.8);//weight and height for calculation of BMI
		double expectedBMI=160*703/(70.8*70.8);//Expecting 22.44 as the output.
		  Assert.assertEquals(expectedBMI,actualBMI, EPSILON);
	}
	
	//THIS TEST WOULD FAIL. 
	@Test
	/*** Method for failure test of BMI calculation*/
	//Test case for incorrectBMI method
	public void testincorrectBMI() {
		MyHealthDatabase healthdatabase=new MyHealthDatabase();
		double actualBMI= Math.round(healthdatabase.incorrectBMI(160, 70.8));//weight and height for calculation of BMI
		double expectedBMI=22;//Expecting 22 as the output.
		  Assert.assertNotEquals(expectedBMI,actualBMI, EPSILON);
	}
}
