package assign1;
/*• Author: [Arbutha_Durairaj,041156799] 
• Course: CST8284-Object Oriented Programming
• Assignment: Assignment1
• Date:October11,2024
• Professor:Gustavo Adami
• Purpose:Creating and maintaining Electronic health records of patients in hospital
• Class list: */
/**
* MyHealthDataBase is a base class to be extended for the Electronic Health Records (EHR) System,
* also known as Assignment 1.  It contains a method to calculate BMI and will contain other methods.
* @author Arbutha_Durairaj
* @version 1.2
* @since 17.0.11
* @see MyHealthDatabase
*/
public class MyHealthDatabase {
	/** 
	    * This method returns the calculated Body Mass Index (BMI) from data provided.
	    * @param weightParam Weight of the patient in pounds.
	    * @param heightParam Height of the patient in inches.
	    */
	public double calculateBMI(double weightParam, double heightParam)
    {
		/**@return BMI the BMI calculated results of patients*/
        double BMI=weightParam * 703 / (heightParam * heightParam);
        return BMI;
    }
	/** 
	    * This method returns the calculated Body Mass Index (BMI) from data provided.
	    * @param weightParam Weight of the patient in pounds.
	    * @param heightParam Height of the patient in inches.
	    
	    */
	public double incorrectBMI(double weightParam, double heightParam)
    {
		/** @Return BMI the incorrect BMI results of patients*/
       double BMI=weightParam  + 703 / (heightParam * heightParam);
       return BMI;
    }

}
