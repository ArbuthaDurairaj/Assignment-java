package assign1;
import java.time.LocalDate;
import java.util.Scanner;

/*• Author: [Arbutha Durairaj,041156799] 
• Course: CST8284-Object Oriented Programming
• Assignment: Assignment1
• Date:October11,2024
• Professor:Gustavo Adami
• Purpose:Creating and maintaining Electronic health records of patients in hospital
• Class list: */
/**
 * This class is designed to  create patient's health records during 
their first time in the hospital. 
  @author Arbutha_Durairaj
 * @version 1.2
 * @see MyHealthDatatest
 * @since 17.0.11
*/
public class MyHealthDatatest {
	/** The main method to get the information of the patients*/

	public static void main(String[] args) {
/** To get the current year*/		
		 LocalDate CurrentDate=LocalDate.now();
		
	Scanner input =new Scanner(System.in);
	System.out.print("Enter patient's first name: ");
    String firstName = input.nextLine();

    System.out.print("Enter patient's last name: ");
    String lastName = input.nextLine();

    System.out.print("Enter patient's gender as F/M: ");
    String gender = input.nextLine();

    System.out.print("Enter patient's height (in inches): ");
    double height = input.nextDouble();

    System.out.print("Enter patient's weight (in pounds): ");
    double weight = input.nextDouble();

    System.out.print("Enter patient's year of birth: ");
    int birthYear = input.nextInt();

    // Create an instance of MyHealthData
    MyHealthData patientData = new MyHealthData(firstName, lastName, gender, height, weight, birthYear,CurrentDate.getYear());
  
    // Display the patient's health data
   patientData.displayMyHealthData();
   System.out.println("Program by Arbutha Durairaj");
    
    
    input.close();
	}

}
